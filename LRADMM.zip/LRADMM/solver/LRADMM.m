function  out= LRADMM(X,y,pars)
% Inputs:
%       X    -- the sample data, dimension, \in\R^{m-by-n}; (required)
%       y    -- the classes of the sample data, \in\R^m; (required)
%               y_i \in {+1,-1}, i=1,2,...,m
%       pars -- parameters (optional)
%               
% pars:     Parameters are all OPTIONAL
%               pars.alpha   --  Starting point of alpha \in\R^m,  (default, zeros(m,1)) 
%               pars.lambda  --  A positive scalar in (2^-7,2^-6,...,2^7).(default, 1) 
% %             pars.mu      --  A positive scalar in (sqrt(2)^-7,...,sqrt(2)^7).(default, 1)
%               pars.nu      --  A positive scalar (default, 0.1)
%               pars.maxit   --  Maximum number of iterations, (default,1000) 
%               pars.tol     --  Tolerance of the halting condition, (default,1e-3)
%
% Outputs:
%     Out.iter:          Number of iterations
%     Out.time:          CPU time
%     Out.wb:            The solution of the primal problem, namely the classifier
%     Out.u:             The solution u
%     Out.lam:           The solution lambda
%     Out.alpha:         The solution alpha
%     Out.nsv:           Number of support vectors 
%     Out.s:             Sparsity level of the solution Out.alpha
%     Out.acc:           Classification accuracy
%     Out.error:         Classification error
%%%%%%%    The code was based on the algorithm proposed in
%%%%%%%    H.J. Wang, Y.H. Shao, 
%%%%%%%    Fast generalized ramp loss support vector machine for pattern classification,



 
if nargin<3;               pars  = [];                             end
if isfield(pars,'maxit');  maxit = pars.maxit; else; maxit = 1e3;  end
if isfield(pars,'mu');     mu = pars.mu; else; mu = 1;    end
if isfield(pars,'tol');    tol   = pars.tol;   else; tol   = 1e-3; end
if isfield(pars,'lambda'); lambda= pars.lambda;else; lambda     = 1;    end
if isfield(pars,'nu');     nu    = pars.nu;     else; nu   = 0.001;    end
[m,n]  = size(X);
w      = ones(n,1)/100; % w=zeros(n,1);
lam    = zeros(m,1);
lamsig = lam; 
T      = GetT(y,m,n);
A      = y.*X; 
r      = 1-A*w;
b      = 0;   %b= 1 or -1;
z      = r-b*y;
theta  = ones(1,4);
Fnorm  = @(var)norm(var)^2;
flag   = 0;
to     = tic; 
for iter  = 1:1:maxit
    
    % update T -------------------------------------
    if flag==1 || m<n || m>10000 && lambda/(mu*nu^2)>=2 
       con = sqrt(2*lambda/mu);
       T   = find(z >0 & z <= con);
    else
       T1   = find(z>0 & z<lambda/(mu*nu)); 
       T2   = find(z>=lambda/(mu*nu) & z<=nu+lambda/(2*mu*nu));
       T    = union(T1, T2);
     end
    % update u ------------------------------------- 
    if lambda/(mu*nu^2)>=2
         u = Prox(z,lambda,mu,T);
    else 
         u = Prox1(z,lambda,mu,nu,T1,T2);
    end
    % update w--------------------------------------
    tmp    = 1 - u - lamsig;
    v      = tmp - b*y;
    nT     = nnz(T);        
    AT     = A(T,:); 
    if min(n,nT)< 1e3         
        ATt     = AT';   
        if  n  <= nT
            AAT = ATt*AT;
            AAT(1:1+n:end) = AAT(1:1+n:end) + 1/mu;  
            w   = AAT\(ATt*v(T));
        else
            if nT >0
                AAT = AT *ATt;
                AAT(1:1+nT:end) = AAT(1:1+nT:end) + 1/mu; 
                w  = ATt*(AAT\v(T));
            else
                w  = -ones(n,1); T=1;
            end 
        end
    else   
        if  n  <= nT 
            w = my_cg(AT,mu,(v(T)'*AT)',n,1);  
        else
            wT = my_cg(AT,mu,v(T),nT,2); 
            w  = (wT'*AT)';
        end  
    end
 
    % update b------------------------------------- 
    Aw     = A*w; 
    b      = mean((tmp(T)-Aw(T)).*y(T)); 

    
    % update lambda------------------------------- 
    lamT   = lam(T);
    lam    = zeros(m,1);
    omega  = Aw + u - 1 + b*y;
    lamT   = lamT + mu * omega(T);  
    lam(T) = lamT;
    
 
     % stopping crterion -------------------------- 
    lamsig = lam/mu;
    ulam   = u  - lamsig; 
    ind    = (ulam<=0 | ulam>sqrt(2*lambda/mu)); 
  
    theta(1) = Fnorm(w'+ lamT'*AT)/(1+Fnorm(w));
    theta(2) = abs(y(T)'*lamT)/(1+nT); 
    theta(3) = Fnorm(omega)/(m+Fnorm(Aw)); %
    if lambda/(mu*nu^2)>=2 
    theta(4) = Fnorm(u-ulam.*ind)/(1+Fnorm(u));
    else 
    theta(4) = Fnorm(u - Prox1(z,lambda,mu,nu,T1,T2))/(1+Fnorm(u));
    end
    error    = max(theta); 
     CPU     = toc(to);
    ACC      = 1-nnz(sign(y.*Aw+b)-y)/length(y);
   tACC(iter)= ACC;
    if error < tol && ACC>0.5; flag=2; break;  end
    
    z        = ulam - omega;
    sig0     = min(z(z>0));  
    if isempty(sig0); sig0 = 1e-8; end
    
    if mod(iter,10)==0 
        if theta(3) > 1e-3
           mu = min(mu*2,10);   
        elseif theta(1) > 1e-3
           mu = min(max(0.01,mu/1.25),5);  
        end         
    end
 if    m<n || m>10000
    if mu > 2*lambda/sig0^2  % exclude zero solutions
       mu = 1.9*lambda/sig0^2;  
    end
 end
 
 if iter>5 && m>n && m<=10000
     
 if std(tACC(iter-3:iter))<=1e-3
  Cons = sqrt(2*lambda/mu);  m0   = max(20,2*n);
  T0   = find(z >0 & z <= Cons); 
  
 if nnz(T0)<5 || nnz(T0)>=m0
    flag=1;  z1 = z(find(z>0));
 if nnz(z1)>m0
    s  = mink(z1,m0);    mu = min(2*lambda/s(m0)^2,10000);
 else
 [~,T] = mink(abs(z),m0); flag=0;
  end
  end
  end
  end
end
% fprintf('----------------------------------------------------\n');

out.iter = iter;
out.time = CPU;
out.wb   = [w;b];
out.u    = u;
out.lam  = lam;
out.nsv  = nT;
out.acc  = ACC;
out.error= error;
out.flag = flag;
end

% proxiaml-----------------------------------------------------------------
function u = Prox(z,lambda,mu,T)
if isempty(T)
    tmp1 = sqrt(2*lambda/mu);
    T    = find(z >0 & z <= tmp1);
    u    = z;
    u(T) = 0;
   else
    u    = z;
    u(T) = 0;
 end
       
end

function u = Prox1(z,lambda,mu,nu,T1,T2)
   T=union(T1, T2);
if isempty(T)
    tmp1 = sqrt(2*lambda/mu);
    T    = find(z >0 & z <= tmp1);
    u    = z;
    u(T) = 0;
else
    u    = z;
    u(T1)= 0;
    u(T2)= z(T2)-lambda/(mu*nu);
 end
       
end

% %%% -----------------------------------------------------------------
function T = GetT(y,m,n)
if  m>n   
s0      = ceil(n*(log(m/n))^2); 
T1      = find(y==1);  nT1= nnz(T1);
T2      = find(y==-1); nT2= nnz(T2);
if  nT1 < s0
    T  = [T1; T2(1:(s0-nT1))];   
elseif nT2 < s0
    T  = [T1(1:(s0-nT2)); T2]; 
else 
    T  = [T1(1:ceil(s0/2)); T2(1:(s0-ceil(s0/2)))];    
end
T      = sort(T(1:s0));
else
    T  = 1:length(y);
end
end

% Conjugate gradient method-------------------------------------------------
function x = my_cg(AT,mu,b,n,flag)
    x = zeros(n,1);
    r = b;
    e = sum(r.*r);
    t = e;
    for i = 1: 50  
        if e < 1e-10*t; break; end
        if  i == 1  
            p = r;
        else
            p = r + (e/e0)*p;
        end
        if  flag==1 
            w  = p/mu  + ((AT*p)'*AT)'; 
        else
            w  = p/mu  + AT*(p'*AT)'; 
        end 
        a  = e/sum(p.*w); 
        x  = x + a * p;
        r  = r - a * w;
        e0 = e;
        e  = sum(r.*r);
    end
    
end