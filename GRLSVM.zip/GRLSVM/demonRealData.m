clear all; clc; close all;
addpath(genpath(pwd));
load Austrain
X      = normalization(X,2);
y      = Y;  y(y~=1)= -1;  
[M,n]  = size(X);         
X      = normalization(X,2); % normalize the data
 
% randomly split the data into training and testing data
m  = ceil(0.9*M);  mt = M-m;       I  = randperm(M);
Tt = I(1:mt);      Xt = X(Tt,:);   yt = y(Tt);   % testing  data 
T  = I(1+mt:end);  X  = X(T,:);    y  = y(T,:);  % training data
 

fprintf(' ------------------------------------------------------------------------\n');
fprintf('      lambda      mu     Iter      ACC       tACC       NSV        TIME\n');
fprintf(' ------------------------------------------------------------------------\n');

for i          = -3:1:3
    pars.lambda     = 2^i; %nu=0.1
    for  j     = -5:1:5
    pars.mu = 2^j;
    out        = GRSVM(X,y,pars); 
    wb         = out.wb;
    if out.flag==2 
       tACC    = accuracy(Xt,yt,wb);  
       fprintf(' | %5.2f  |  %5.2f  |  %3d  |  %6.4f  |  %6.4f  |  %4d  |  %5.3fsec  |\n',...
       pars.lambda, pars.mu, out.iter, out.acc,  tACC,out.nsv,out.time);
    end
    end
end 

