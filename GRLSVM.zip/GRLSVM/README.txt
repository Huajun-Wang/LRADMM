This source code is programmed based on the algorithm described in:

H.J. Wang, Y.H. Shao, 
Fast generalized ramp loss support vector machine for pattern classification

Please give credits to this paper if you use the code for your research.
